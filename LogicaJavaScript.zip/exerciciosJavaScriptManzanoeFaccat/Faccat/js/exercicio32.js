/**
 * Vencedor_Partida
 * Convertido do VisualG: Exercício 32.alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 16
 */
function exercicio32() {
  let gols1 = 0, gols2 = 0; // inteiro
  let time1 = "", time2 = ""; // literal

  time1 = prompt("Nome do time 1: ");
  gols1 = parseInt(prompt("Gols do time 1: "));
  time2 = prompt("Nome do time 2: ");
  gols2 = parseInt(prompt("Gols do time 2: "));
  if (gols1 > gols2) {   // <-- breakpoint sugerido
    mostrar("Vencedor: " + time1);
  } else {
    if (gols2 > gols1) {
      mostrar("Vencedor: " + time2);
    } else {
      mostrar("EMPATE");
    }
  }
}
