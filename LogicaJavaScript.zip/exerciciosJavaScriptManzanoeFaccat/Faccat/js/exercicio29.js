/**
 * Soma_dos_Dois_Maiores
 * Convertido do VisualG: Exercício 29.alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 14
 */
function exercicio29() {
  let a = 0, b = 0, c = 0, soma = 0; // real

  a = parseFloat(prompt("Digite o valor de A: ").replace(",", "."));
  b = parseFloat(prompt("Digite o valor de B: ").replace(",", "."));
  c = parseFloat(prompt("Digite o valor de C: ").replace(",", "."));
  if ((a < b) && (a < c)) {   // <-- breakpoint sugerido
    soma = b + c;
  } else {
    if (b < c) {
      soma = a + c;
    } else {
      soma = a + b;
    }
  }
  mostrar("A soma dos dois maiores e: " + soma);
}
