/**
 * Fruteira
 * Convertido do VisualG: Exercício 37.alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 13
 */
function exercicio37() {
  let kgMorango = 0, kgMaca = 0, precoMorango = 0, precoMaca = 0, totalKg = 0, total = 0, desconto = 0, valorPago = 0; // real

  kgMorango = parseFloat(prompt("Kg de morango: ").replace(",", "."));
  kgMaca = parseFloat(prompt("Kg de maca: ").replace(",", "."));
  if (kgMorango <= 5) {   // <-- breakpoint sugerido
    precoMorango = 2.50;
  } else {
    precoMorango = 2.20;
  }
  if (kgMaca <= 5) {
    precoMaca = 1.80;
  } else {
    precoMaca = 1.50;
  }
  total = kgMorango * precoMorango + kgMaca * precoMaca;
  totalKg = kgMorango + kgMaca;
  if ((totalKg > 8) || (total > 25)) {
    desconto = total * 10 / 100;
  } else {
    desconto = 0;
  }
  valorPago = total - desconto;
  mostrar("Valor a pagar: R$ " + valorPago);
}
