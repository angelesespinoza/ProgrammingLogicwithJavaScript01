/**
 * Duracao_Jogo_Xadrez
 * Convertido do VisualG: Exercício 21.alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 13
 */
function exercicio21() {
  let horaInicio = 0, horaFim = 0, duracao = 0; // inteiro

  horaInicio = parseInt(prompt("Hora de inicio (0 a 23): "));
  horaFim = parseInt(prompt("Hora de fim (0 a 23): "));
  if (horaFim > horaInicio) {   // <-- breakpoint sugerido
    duracao = horaFim - horaInicio;
  } else {
    duracao = 24 - horaInicio + horaFim;
  }
  mostrar("Duracao do jogo em horas: " + duracao);
}
