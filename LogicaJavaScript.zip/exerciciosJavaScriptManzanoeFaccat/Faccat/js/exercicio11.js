/**
 * Salario_Vendedor
 * Convertido do VisualG: Exercício 11.alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 16
 */
function exercicio11() {
  let numCarros = 0; // inteiro
  let totalVendas = 0, salarioFixo = 0, valorCarro = 0, comissaoCarros = 0, comissaoVendas = 0, salarioFinal = 0; // real

  numCarros = parseInt(prompt("Numero de carros vendidos: "));
  totalVendas = parseFloat(prompt("Valor total das vendas: ").replace(",", "."));
  salarioFixo = parseFloat(prompt("Salario fixo: ").replace(",", "."));
  valorCarro = parseFloat(prompt("Valor recebido por carro vendido: ").replace(",", "."));
  comissaoCarros = numCarros * valorCarro;   // <-- breakpoint sugerido
  comissaoVendas = totalVendas * 5 / 100;
  salarioFinal = salarioFixo + comissaoCarros + comissaoVendas;
  mostrar("O salario final do vendedor e: " + salarioFinal);
}
