/**
 * Troca_A_B
 * Convertido do VisualG: Exercício 1.alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 11
 */
function exercicio01() {
  let a = 0, b = 0, aux = 0; // inteiro

  a = 10;   // <-- breakpoint sugerido
  b = 20;
  aux = a;
  a = b;
  b = aux;
  mostrar("A = " + a);
  mostrar("B = " + b);
}
