/**
 * Desconto_Produto
 * Convertido do VisualG: Exercício 40.alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 16
 */
function exercicio40() {
  let quantidade = 0; // inteiro
  let precoUnitario = 0, total = 0, desconto = 0, totalPagar = 0; // real
  let nome = ""; // literal

  nome = prompt("Descricao do produto: ");
  quantidade = parseInt(prompt("Quantidade adquirida: "));
  precoUnitario = parseFloat(prompt("Preco unitario: ").replace(",", "."));
  total = quantidade * precoUnitario;   // <-- breakpoint sugerido
  if (quantidade <= 5) {
    desconto = total * 2 / 100;
  } else {
    if (quantidade <= 10) {
      desconto = total * 3 / 100;
    } else {
      desconto = total * 5 / 100;
    }
  }
  totalPagar = total - desconto;
  mostrar("Produto: " + nome);
  mostrar("Total: " + total);
  mostrar("Desconto: " + desconto);
  mostrar("Total a pagar: " + totalPagar);
}
