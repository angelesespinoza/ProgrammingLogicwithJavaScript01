/**
 * Fahrenheit_para_Celsius
 * Convertido do VisualG: Exercício 12.alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 12
 */
function exercicio12() {
  let f = 0, c = 0; // real

  f = parseFloat(prompt("Digite a temperatura em Fahrenheit: ").replace(",", "."));
  c = 5 * (f - 32) / 9;   // <-- breakpoint sugerido
  mostrar("A temperatura em Celsius e: " + c);
}
