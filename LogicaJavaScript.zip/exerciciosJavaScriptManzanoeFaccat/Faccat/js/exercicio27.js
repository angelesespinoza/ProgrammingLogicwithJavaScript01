/**
 * Positivo_Negativo_Zero
 * Convertido do VisualG: Exercício 27.alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 12
 */
function exercicio27() {
  let valor = 0; // real

  valor = parseFloat(prompt("Digite um valor: ").replace(",", "."));
  if (valor > 0) {   // <-- breakpoint sugerido
    mostrar("Positivo");
  } else {
    if (valor < 0) {
      mostrar("Negativo");
    } else {
      mostrar("Zero");
    }
  }
}
