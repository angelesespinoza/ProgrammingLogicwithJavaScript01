/**
 * Custo_Final_Carro
 * Convertido do VisualG: Exercício 10.alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 12
 */
function exercicio10() {
  let custoFabrica = 0, distribuidor = 0, impostos = 0, custoFinal = 0; // real

  custoFabrica = parseFloat(prompt("Custo de fabrica: ").replace(",", "."));
  distribuidor = custoFabrica * 28 / 100;   // <-- breakpoint sugerido
  impostos = custoFabrica * 45 / 100;
  custoFinal = custoFabrica + distribuidor + impostos;
  mostrar("Custo final ao consumidor: " + custoFinal);
}
