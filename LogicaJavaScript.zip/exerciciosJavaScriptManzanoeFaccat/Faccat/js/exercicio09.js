/**
 * Novo_Salario
 * Convertido do VisualG: Exercício 9.alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 13
 */
function exercicio09() {
  let salario = 0, percentual = 0, aumento = 0, novoSalario = 0; // real

  salario = parseFloat(prompt("Salario atual: ").replace(",", "."));
  percentual = parseFloat(prompt("Percentual de reajuste: ").replace(",", "."));
  aumento = salario * percentual / 100;   // <-- breakpoint sugerido
  novoSalario = salario + aumento;
  mostrar("O novo salario e: " + novoSalario);
}
