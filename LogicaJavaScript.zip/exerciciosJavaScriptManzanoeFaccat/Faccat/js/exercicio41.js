/**
 * Media_Aproveitamento
 * Convertido do VisualG: Exercício 41.alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 16
 */
function exercicio41() {
  let n1 = 0, n2 = 0, n3 = 0, mediaExercicios = 0, mediaAproveitamento = 0; // real
  let conceito = ""; // literal

  n1 = parseFloat(prompt("Nota da 1a verificacao: ").replace(",", "."));
  n2 = parseFloat(prompt("Nota da 2a verificacao: ").replace(",", "."));
  n3 = parseFloat(prompt("Nota da 3a verificacao: ").replace(",", "."));
  mediaExercicios = parseFloat(prompt("Media dos exercicios: ").replace(",", "."));
  mediaAproveitamento = (n1 + n2 * 2 + n3 * 3 + mediaExercicios) / 7;   // <-- breakpoint sugerido
  if (mediaAproveitamento >= 9) {
    conceito = "A";
  } else {
    if (mediaAproveitamento >= 7.5) {
      conceito = "B";
    } else {
      if (mediaAproveitamento >= 6) {
        conceito = "C";
      } else {
        conceito = "D";
      }
    }
  }
  mostrar("Media de aproveitamento: " + mediaAproveitamento);
  mostrar("Conceito: " + conceito);
}
