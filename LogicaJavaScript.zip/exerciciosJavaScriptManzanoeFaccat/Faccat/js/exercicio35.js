/**
 * Posto_Combustivel
 * Convertido do VisualG: Exercício 35.alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 14
 */
function exercicio35() {
  let litros = 0, preco = 0, desconto = 0, valorPago = 0; // real
  let tipo = ""; // literal

  litros = parseFloat(prompt("Litros vendidos: ").replace(",", "."));
  tipo = prompt("Tipo de combustivel (A-alcool, G-gasolina): ");
  if (tipo === "A") {   // <-- breakpoint sugerido
    preco = 2.90;
    if (litros <= 20) {
      desconto = 3;
    } else {
      desconto = 5;
    }
    valorPago = litros * preco * (1 - desconto / 100);
    mostrar("Valor a pagar: R$ " + valorPago);
  } else {
    if (tipo === "G") {
      preco = 3.30;
      if (litros <= 20) {
        desconto = 4;
      } else {
        desconto = 6;
      }
      valorPago = litros * preco * (1 - desconto / 100);
      mostrar("Valor a pagar: R$ " + valorPago);
    } else {
      mostrar("Tipo de combustivel invalido");
    }
  }
}
