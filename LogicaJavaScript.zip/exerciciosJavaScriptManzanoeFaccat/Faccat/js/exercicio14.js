/**
 * Maior_Que_10
 * Convertido do VisualG: Exercício 14.alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 12
 */
function exercicio14() {
  let valor = 0; // real

  valor = parseFloat(prompt("Digite um valor: ").replace(",", "."));
  if (valor > 10) {   // <-- breakpoint sugerido
    mostrar("É MAIOR QUE 10!");
  } else {
    mostrar("NÃO É MAIOR QUE 10!");
  }
}
