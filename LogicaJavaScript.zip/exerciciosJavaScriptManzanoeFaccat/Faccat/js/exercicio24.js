/**
 * Salario_Comissao
 * Convertido do VisualG: Exercício 24.alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 13
 */
function exercicio24() {
  let salarioFixo = 0, vendas = 0, comissao = 0, salarioTotal = 0; // real

  salarioFixo = parseFloat(prompt("Salario fixo: ").replace(",", "."));
  vendas = parseFloat(prompt("Valor das vendas: ").replace(",", "."));
  if (vendas <= 1500) {   // <-- breakpoint sugerido
    comissao = vendas * 3 / 100;
  } else {
    comissao = 1500 * 3 / 100 + (vendas - 1500) * 5 / 100;
  }
  salarioTotal = salarioFixo + comissao;
  mostrar("Salario total: " + salarioTotal);
}
