/**
 * Idade_em_Dias
 * Convertido do VisualG: Exercício 7.alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 14
 */
function exercicio07() {
  let anos = 0, meses = 0, dias = 0, idadeDias = 0; // inteiro

  anos = parseInt(prompt("Digite os anos: "));
  meses = parseInt(prompt("Digite os meses: "));
  dias = parseInt(prompt("Digite os dias: "));
  idadeDias = anos * 365 + meses * 30 + dias;   // <-- breakpoint sugerido
  mostrar("A idade em dias e: " + idadeDias);
}
