/**
 * Salario_Horas_Extras
 * Convertido do VisualG: Exercício 22.alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 13
 */
function exercicio22() {
  let horas = 0, salHora = 0, limite = 0, extras = 0, salTotal = 0; // real

  horas = parseFloat(prompt("Horas trabalhadas no mes: ").replace(",", "."));
  salHora = parseFloat(prompt("Salario por hora: ").replace(",", "."));
  limite = 40 * 4;   // <-- breakpoint sugerido
  if (horas > limite) {
    extras = horas - limite;
    salTotal = limite * salHora + extras * salHora * 1.5;
  } else {
    salTotal = horas * salHora;
  }
  mostrar("Salario total: " + salTotal);
}
