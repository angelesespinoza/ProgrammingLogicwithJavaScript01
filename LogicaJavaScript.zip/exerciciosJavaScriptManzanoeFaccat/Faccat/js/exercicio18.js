/**
 * Pode_Votar
 * Convertido do VisualG: Exercício 18.alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 13
 */
function exercicio18() {
  let anoAtual = 0, anoNascimento = 0, idade = 0; // inteiro

  anoAtual = parseInt(prompt("Ano atual: "));
  anoNascimento = parseInt(prompt("Ano de nascimento: "));
  idade = anoAtual - anoNascimento;   // <-- breakpoint sugerido
  if (idade >= 16) {
    mostrar("Podera votar este ano");
  } else {
    mostrar("Nao podera votar este ano");
  }
}
