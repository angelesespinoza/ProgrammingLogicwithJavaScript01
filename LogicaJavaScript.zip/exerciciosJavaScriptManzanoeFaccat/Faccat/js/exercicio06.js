/**
 * Area_Retangulo
 * Convertido do VisualG: Exercício 6.alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 13
 */
function exercicio06() {
  let base = 0, altura = 0, area = 0; // real

  base = parseFloat(prompt("Digite a base: ").replace(",", "."));
  altura = parseFloat(prompt("Digite a altura: ").replace(",", "."));
  area = base * altura;   // <-- breakpoint sugerido
  mostrar("A area do retangulo e: " + area);
}
