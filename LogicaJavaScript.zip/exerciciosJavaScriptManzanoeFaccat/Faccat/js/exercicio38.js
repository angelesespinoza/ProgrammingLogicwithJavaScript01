/**
 * Acesso_Usuario
 * Convertido do VisualG: Exercício 38.alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 12
 */
function exercicio38() {
  let codigo = 0, senha = 0; // inteiro

  codigo = parseInt(prompt("Digite o codigo de usuario: "));
  if (codigo !== 1234) {   // <-- breakpoint sugerido
    mostrar("Usuário inválido!");
  } else {
    senha = parseInt(prompt("Digite a senha: "));
    if (senha !== 9999) {
      mostrar("senha incorreta");
    } else {
      mostrar("Acesso permitido");
    }
  }
}
