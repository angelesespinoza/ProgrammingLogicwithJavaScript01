/**
 * Idades_Homens_Mulheres
 * Convertido do VisualG: Exercício 36.alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 15
 */
function exercicio36() {
  let h1 = 0, h2 = 0, m1 = 0, m2 = 0, homemVelho = 0, homemNovo = 0, mulherVelha = 0, mulherNova = 0, soma = 0, produto = 0; // inteiro

  h1 = parseInt(prompt("Idade do homem 1: "));
  h2 = parseInt(prompt("Idade do homem 2: "));
  m1 = parseInt(prompt("Idade da mulher 1: "));
  m2 = parseInt(prompt("Idade da mulher 2: "));
  if (h1 > h2) {   // <-- breakpoint sugerido
    homemVelho = h1;
    homemNovo = h2;
  } else {
    homemVelho = h2;
    homemNovo = h1;
  }
  if (m1 > m2) {
    mulherVelha = m1;
    mulherNova = m2;
  } else {
    mulherVelha = m2;
    mulherNova = m1;
  }
  soma = homemVelho + mulherNova;
  produto = homemNovo * mulherVelha;
  mostrar("Soma (homem mais velho + mulher mais nova): " + soma);
  mostrar("Produto (homem mais novo x mulher mais velha): " + produto);
}
