/**
 * Aposentadoria
 * Convertido do VisualG: Exercício 42.alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 15
 */
function exercicio42() {
  let codigo = 0, anoNascimento = 0, anoIngresso = 0, anoAtual = 0, idade = 0, tempoTrabalho = 0; // inteiro

  codigo = parseInt(prompt("Numero do empregado: "));
  anoNascimento = parseInt(prompt("Ano de nascimento: "));
  anoIngresso = parseInt(prompt("Ano de ingresso na empresa: "));
  anoAtual = parseInt(prompt("Ano atual: "));
  idade = anoAtual - anoNascimento;   // <-- breakpoint sugerido
  tempoTrabalho = anoAtual - anoIngresso;
  mostrar("Idade: " + idade);
  mostrar("Tempo de trabalho: " + tempoTrabalho);
  if ((idade >= 65) || (tempoTrabalho >= 30) || ((idade >= 60) && (tempoTrabalho >= 25))) {
    mostrar("Requerer aposentadoria");
  } else {
    mostrar("Não requerer");
  }
}
