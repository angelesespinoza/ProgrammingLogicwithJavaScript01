/**
 * Custo_Macas
 * Convertido do VisualG: Exercício 16.alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 13
 */
function exercicio16() {
  let macas = 0; // inteiro
  let custo = 0; // real

  macas = parseInt(prompt("Quantidade de macas: "));
  if (macas < 12) {   // <-- breakpoint sugerido
    custo = macas * 1.30;
  } else {
    custo = macas * 1.00;
  }
  mostrar("O custo total da compra e: R$ " + custo);
}
