/**
 * Aprovacao_Media
 * Convertido do VisualG: Exercício 17.alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 13
 */
function exercicio17() {
  let n1 = 0, n2 = 0, media = 0; // real

  n1 = parseFloat(prompt("Nota da 1a avaliacao: ").replace(",", "."));
  n2 = parseFloat(prompt("Nota da 2a avaliacao: ").replace(",", "."));
  media = (n1 + n2) / 2;   // <-- breakpoint sugerido
  if (media >= 6) {
    mostrar("Aluno aprovado");
  } else {
    mostrar("Aluno nao aprovado");
  }
  mostrar("Media: " + media);
}
