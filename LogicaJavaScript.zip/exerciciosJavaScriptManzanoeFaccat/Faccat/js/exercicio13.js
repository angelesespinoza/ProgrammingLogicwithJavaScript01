/**
 * Media_Ponderada
 * Convertido do VisualG: Exercício 13.alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 14
 */
function exercicio13() {
  let n1 = 0, n2 = 0, n3 = 0, mediafinal = 0; // real

  n1 = parseFloat(prompt("Digite a nota 1: ").replace(",", "."));
  n2 = parseFloat(prompt("Digite a nota 2: ").replace(",", "."));
  n3 = parseFloat(prompt("Digite a nota 3: ").replace(",", "."));
  mediafinal = (n1 * 2 + n2 * 3 + n3 * 5) / 10;   // <-- breakpoint sugerido
  mostrar("A media final e: " + mediafinal);
}
