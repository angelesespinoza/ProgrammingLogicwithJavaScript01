/**
 * Maior_de_Dois
 * Convertido do VisualG: Exercício 19.alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 13
 */
function exercicio19() {
  let a = 0, b = 0; // real

  a = parseFloat(prompt("Digite o primeiro valor: ").replace(",", "."));
  b = parseFloat(prompt("Digite o segundo valor: ").replace(",", "."));
  if (a > b) {   // <-- breakpoint sugerido
    mostrar("O maior valor e: " + a);
  } else {
    mostrar("O maior valor e: " + b);
  }
}
