/**
 * Percentual_Votos
 * Convertido do VisualG: Exercício 8.alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 16
 */
function exercicio08() {
  let tot = 0, vb = 0, vn = 0, vv = 0; // inteiro
  let pb = 0, pn = 0, pv = 0; // real

  tot = parseInt(prompt("Total de eleitores: "));
  vb = parseInt(prompt("Votos brancos: "));
  vn = parseInt(prompt("Votos nulos: "));
  vv = parseInt(prompt("Votos validos: "));
  pb = vb * 100 / tot;   // <-- breakpoint sugerido
  pn = vn * 100 / tot;
  pv = vv * 100 / tot;
  mostrar("Percentual de votos brancos: " + pb + "%");
  mostrar("Percentual de votos nulos: " + pn + "%");
  mostrar("Percentual de votos validos: " + pv + "%");
}
