/**
 * Saldo_Conta
 * Convertido do VisualG: Exercício 25.alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 16
 */
function exercicio25() {
  let numConta = 0; // inteiro
  let saldo = 0, debito = 0, credito = 0, saldoAtual = 0; // real

  numConta = parseInt(prompt("Numero da conta: "));
  saldo = parseFloat(prompt("Saldo: ").replace(",", "."));
  debito = parseFloat(prompt("Debito: ").replace(",", "."));
  credito = parseFloat(prompt("Credito: ").replace(",", "."));
  saldoAtual = saldo - debito + credito;   // <-- breakpoint sugerido
  mostrar("Saldo atual: " + saldoAtual);
  if (saldoAtual >= 0) {
    mostrar("Saldo Positivo");
  } else {
    mostrar("Saldo Negativo");
  }
}
