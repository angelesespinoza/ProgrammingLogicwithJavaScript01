/**
 * Antecessor
 * Convertido do VisualG: Exercício 5.alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 12
 */
function exercicio05() {
  let valor = 0, antecessor = 0; // inteiro

  valor = parseInt(prompt("Digite um valor: "));
  antecessor = valor - 1;   // <-- breakpoint sugerido
  mostrar("O antecessor de " + valor + " e " + antecessor);
}
