/**
 * Peso_Ideal
 * Convertido do VisualG: Exercício 23.alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 15
 */
function exercicio23() {
  let altura = 0, pesoIdeal = 0; // real
  let nome = "", sexo = ""; // literal

  nome = prompt("Nome: ");
  altura = parseFloat(prompt("Altura: ").replace(",", "."));
  sexo = prompt("Sexo (M ou F): ");
  if (sexo === "M") {   // <-- breakpoint sugerido
    pesoIdeal = (72.7 * altura) - 58;
  } else {
    pesoIdeal = (62.1 * altura) - 44.7;
  }
  mostrar("Peso ideal: " + pesoIdeal);
}
