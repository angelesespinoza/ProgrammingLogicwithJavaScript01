/**
 * Tres_Valores_Crescente
 * Convertido do VisualG: Exercício 30.alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 14
 */
function exercicio30() {
  let a = 0, b = 0, c = 0, aux = 0; // real

  a = parseFloat(prompt("Digite o valor de A: ").replace(",", "."));
  b = parseFloat(prompt("Digite o valor de B: ").replace(",", "."));
  c = parseFloat(prompt("Digite o valor de C: ").replace(",", "."));
  if (a > b) {   // <-- breakpoint sugerido
    aux = a;
    a = b;
    b = aux;
  }
  if (a > c) {
    aux = a;
    a = c;
    c = aux;
  }
  if (b > c) {
    aux = b;
    b = c;
    c = aux;
  }
  mostrar("" + a + " " + b + " " + c);
}
