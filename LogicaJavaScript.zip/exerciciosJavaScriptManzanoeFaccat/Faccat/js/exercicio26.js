/**
 * Controle_Estoque
 * Convertido do VisualG: Exercício 26.alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 14
 */
function exercicio26() {
  let qtdAtual = 0, qtdMaxima = 0, qtdMinima = 0, qtdMedia = 0; // real

  qtdAtual = parseFloat(prompt("Quantidade atual em estoque: ").replace(",", "."));
  qtdMaxima = parseFloat(prompt("Quantidade maxima em estoque: ").replace(",", "."));
  qtdMinima = parseFloat(prompt("Quantidade minima em estoque: ").replace(",", "."));
  qtdMedia = (qtdMaxima + qtdMinima) / 2;   // <-- breakpoint sugerido
  mostrar("Quantidade media: " + qtdMedia);
  if (qtdAtual >= qtdMedia) {
    mostrar("Não efetuar compra");
  } else {
    mostrar("Efetuar compra");
  }
}
