/**
 * Impares_0_20
 * Convertido do VisualG: Página 46  Exercício 5.1.1 (D).alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 11
 */
function exercicioD() {
  let numero = 0; // inteiro

  numero = 0;   // <-- breakpoint sugerido
  while (numero <= 20) {
    if (numero % 2 !== 0) {
      mostrar(numero);
    }
    numero = numero + 1;
  }
}
