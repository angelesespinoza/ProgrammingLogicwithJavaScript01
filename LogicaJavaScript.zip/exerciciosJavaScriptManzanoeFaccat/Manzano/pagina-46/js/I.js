/**
 * Soma_Media_10_Valores
 * Convertido do VisualG: Página 46  Exercício 5.1.1 ( I ).alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 12
 */
function exercicioI() {
  let valor = 0, cont = 0; // inteiro
  let soma = 0, media = 0; // real

  soma = 0;   // <-- breakpoint sugerido
  cont = 1;
  while (cont <= 10) {
    valor = parseInt(prompt("Digite o valor " + cont + ": "));
    soma = soma + valor;
    cont = cont + 1;
  }
  media = soma / 10;
  mostrar("Soma: " + soma);
  mostrar("Media aritmetica: " + media);
}
