/**
 * Fibonacci15
 * Convertido do VisualG: Página 46  Exercício 5.1.1 (G).alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 11
 */
function exercicioG() {
  let i = 0, atual = 0, anterior = 0, proximo = 0; // inteiro

  anterior = 1;   // <-- breakpoint sugerido
  atual = 1;
  mostrar("" + anterior + ", " + atual);
  for (i = 3; i <= 15; i++) {
    proximo = anterior + atual;
    mostrar(", " + proximo);
    anterior = atual;
    atual = proximo;
  }
}
