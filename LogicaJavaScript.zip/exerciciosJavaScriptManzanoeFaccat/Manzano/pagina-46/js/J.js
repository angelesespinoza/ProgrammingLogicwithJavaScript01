/**
 * Soma_Media_Pares_50_70
 * Convertido do VisualG: Página 46  Exercício 5.1.1 ( J ).alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 12
 */
function exercicioJ() {
  let numero = 0, qtd = 0; // inteiro
  let soma = 0, media = 0; // real

  numero = 50;   // <-- breakpoint sugerido
  soma = 0;
  qtd = 0;
  while (numero <= 70) {
    if (numero % 2 === 0) {
      soma = soma + numero;
      qtd = qtd + 1;
    }
    numero = numero + 1;
  }
  media = soma / qtd;
  mostrar("Soma dos pares: " + soma);
  mostrar("Media aritmetica dos pares: " + media);
}
