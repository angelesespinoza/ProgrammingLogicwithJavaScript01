/**
 * SomaCemPrimeiros
 * Convertido do VisualG: Página 46  Exercício 5.1.1 (B).alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 11
 */
function exercicioB() {
  let i = 0, soma = 0; // inteiro

  soma = 0;   // <-- breakpoint sugerido
  for (i = 1; i <= 100; i++) {
    soma = soma + i;
  }
  mostrar(soma);
}
