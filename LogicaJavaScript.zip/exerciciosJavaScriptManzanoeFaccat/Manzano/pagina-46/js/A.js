/**
 * Tabuada_Enquanto
 * Convertido do VisualG: Página 46  Exercício 5.1.1 (A).alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 12
 */
function exercicioA() {
  let numero = 0, cont = 0; // inteiro

  numero = parseInt(prompt("Digite um numero para ver a tabuada: "));
  cont = 1;   // <-- breakpoint sugerido
  while (cont <= 10) {
    mostrar("" + numero + " x " + cont + " = " + (numero * cont));
    cont = cont + 1;
  }
}
