/**
 * Potencia_Base_Expoente
 * Convertido do VisualG: Página 46  Exercício 5.1.1 (F).alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 13
 */
function exercicioF() {
  let base = 0, expoente = 0, cont = 0, potencia = 0; // inteiro

  base = parseInt(prompt("Digite a base: "));
  expoente = parseInt(prompt("Digite o expoente: "));
  potencia = 1;   // <-- breakpoint sugerido
  cont = 1;
  while (cont <= expoente) {
    potencia = potencia * base;
    cont = cont + 1;
  }
  mostrar("" + base + " elevado a " + expoente + " e igual a " + potencia);
}
