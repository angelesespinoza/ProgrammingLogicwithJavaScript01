/**
 * Conversao_10_em_10
 * Convertido do VisualG: Página 46  Exercício 5.1.1 (H).alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 12
 */
function exercicioH() {
  let c = 0; // inteiro
  let f = 0; // real

  c = 10;   // <-- breakpoint sugerido
  while (c <= 100) {
    f = (9 * c + 160) / 5;
    mostrar("" + c + " graus Celsius = " + f + " graus Fahrenheit");
    c = c + 10;
  }
}
