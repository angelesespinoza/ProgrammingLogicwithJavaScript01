/**
 * Potencias_de_3
 * Convertido do VisualG: Página 46  Exercício 5.1.1 (E).alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 11
 */
function exercicioE() {
  let expoente = 0, potencia = 0; // inteiro

  expoente = 0;   // <-- breakpoint sugerido
  potencia = 1;
  while (expoente <= 15) {
    mostrar("3^" + expoente + " = " + potencia);
    potencia = potencia * 3;
    expoente = expoente + 1;
  }
}
