/**
 * Numero_Entre_1_e_9
 * Convertido do VisualG: Página 41  Exercício 4 ( J ).alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 12
 */
function exercicioJ() {
  let valor = 0; // inteiro

  valor = parseInt(prompt("Digite um valor: "));
  if ((valor >= 1) && (valor <= 9)) {   // <-- breakpoint sugerido
    mostrar("O valor esta na faixa permitida");
  } else {
    mostrar("O valor esta fora da faixa permitida");
  }
}
