/**
 * Diferenca_Maior_Menor
 * Convertido do VisualG: Página 41  Exercício 4 (A).alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 13
 */
function exercicioA() {
  let a = 0, b = 0, maior = 0, menor = 0, diferenca = 0; // inteiro

  a = parseInt(prompt("Digite o primeiro valor: "));
  b = parseInt(prompt("Digite o segundo valor: "));
  if (a > b) {   // <-- breakpoint sugerido
    maior = a;
    menor = b;
  } else {
    maior = b;
    menor = a;
  }
  diferenca = maior - menor;
  mostrar("A diferenca entre o maior e o menor valor e: " + diferenca);
}
