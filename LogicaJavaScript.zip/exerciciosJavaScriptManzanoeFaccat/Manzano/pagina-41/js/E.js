/**
 * Equacao_Segundo_Grau
 * Convertido do VisualG: Página 41  Exercício 4 (E).alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 14
 */
function exercicioE() {
  let a = 0, b = 0, c = 0, delta = 0, raiz1 = 0, raiz2 = 0; // real

  a = parseFloat(prompt("Digite o valor de A (diferente de zero): ").replace(",", "."));
  b = parseFloat(prompt("Digite o valor de B: ").replace(",", "."));
  c = parseFloat(prompt("Digite o valor de C: ").replace(",", "."));
  if (a !== 0) {   // <-- breakpoint sugerido
    delta = b**2 - 4 * a * c;
    if (delta >= 0) {
      raiz1 = (-b + Math.sqrt(delta)) / (2 * a);
      raiz2 = (-b - Math.sqrt(delta)) / (2 * a);
      mostrar("Raiz 1 = " + raiz1);
      mostrar("Raiz 2 = " + raiz2);
    } else {
      mostrar("A equacao nao possui raizes reais");
    }
  } else {
    mostrar("O valor de A deve ser diferente de zero");
  }
}
