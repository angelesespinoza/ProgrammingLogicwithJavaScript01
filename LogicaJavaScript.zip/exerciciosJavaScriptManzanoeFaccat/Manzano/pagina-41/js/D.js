/**
 * Media_Escolar_Exame
 * Convertido do VisualG: Página 41  Exercício 4 (D).alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 15
 */
function exercicioD() {
  let n1 = 0, n2 = 0, n3 = 0, n4 = 0, exame = 0, media = 0, novaMedia = 0; // real

  n1 = parseFloat(prompt("Digite a 1a nota: ").replace(",", "."));
  n2 = parseFloat(prompt("Digite a 2a nota: ").replace(",", "."));
  n3 = parseFloat(prompt("Digite a 3a nota: ").replace(",", "."));
  n4 = parseFloat(prompt("Digite a 4a nota: ").replace(",", "."));
  media = (n1 + n2 + n3 + n4) / 4;   // <-- breakpoint sugerido
  if (media >= 7) {
    mostrar("Aluno aprovado");
  } else {
    exame = parseFloat(prompt("Digite a nota do exame: ").replace(",", "."));
    novaMedia = (media + exame) / 2;
    if (novaMedia >= 5) {
      mostrar("Aluno aprovado em exame");
    } else {
      mostrar("Aluno nao aprovado");
    }
    media = novaMedia;
  }
  mostrar("Media do aluno: " + media);
}
