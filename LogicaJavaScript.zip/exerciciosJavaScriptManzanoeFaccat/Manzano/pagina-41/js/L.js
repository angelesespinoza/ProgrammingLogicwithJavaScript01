/**
 * Saudacao_Sexo
 * Convertido do VisualG: Página 41  Exercício 4 ( L ).alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 13
 */
function exercicioL() {
  let nome = "", sexo = ""; // literal

  nome = prompt("Digite o nome: ");
  sexo = prompt("Digite o sexo (M para masculino, F para feminino): ");
  if (sexo === "M") {   // <-- breakpoint sugerido
    mostrar("Ilmo Sr. " + nome);
  } else {
    mostrar("Ilma Sra. " + nome);
  }
}
