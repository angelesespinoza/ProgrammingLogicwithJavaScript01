/**
 * Maior_Menor_Cinco_Numeros
 * Convertido do VisualG: Página 41  Exercício 4 (H).alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 16
 */
function exercicioH() {
  let n1 = 0, n2 = 0, n3 = 0, n4 = 0, n5 = 0, maior = 0, menor = 0; // inteiro

  n1 = parseInt(prompt("Digite o 1o numero: "));
  n2 = parseInt(prompt("Digite o 2o numero: "));
  n3 = parseInt(prompt("Digite o 3o numero: "));
  n4 = parseInt(prompt("Digite o 4o numero: "));
  n5 = parseInt(prompt("Digite o 5o numero: "));
  maior = n1;   // <-- breakpoint sugerido
  menor = n1;
  if (n2 > maior) {
    maior = n2;
  }
  if (n2 < menor) {
    menor = n2;
  }
  if (n3 > maior) {
    maior = n3;
  }
  if (n3 < menor) {
    menor = n3;
  }
  if (n4 > maior) {
    maior = n4;
  }
  if (n4 < menor) {
    menor = n4;
  }
  if (n5 > maior) {
    maior = n5;
  }
  if (n5 < menor) {
    menor = n5;
  }
  mostrar("Maior valor: " + maior);
  mostrar("Menor valor: " + menor);
}
