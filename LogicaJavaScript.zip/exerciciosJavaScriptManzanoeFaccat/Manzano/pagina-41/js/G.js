/**
 * Divisiveis_2_3
 * Convertido do VisualG: Página 41  Exercício 4 (G).alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 15
 */
function exercicioG() {
  let a = 0, b = 0, c = 0, d = 0; // inteiro

  a = parseInt(prompt("Digite o valor de A: "));
  b = parseInt(prompt("Digite o valor de B: "));
  c = parseInt(prompt("Digite o valor de C: "));
  d = parseInt(prompt("Digite o valor de D: "));
  if (a % 2 === 0) {   // <-- breakpoint sugerido
    mostrar("" + a + " e divisivel por 2");
  }
  if (a % 3 === 0) {
    mostrar("" + a + " e divisivel por 3");
  }
  if (b % 2 === 0) {
    mostrar("" + b + " e divisivel por 2");
  }
  if (b % 3 === 0) {
    mostrar("" + b + " e divisivel por 3");
  }
  if (c % 2 === 0) {
    mostrar("" + c + " e divisivel por 2");
  }
  if (c % 3 === 0) {
    mostrar("" + c + " e divisivel por 3");
  }
  if (d % 2 === 0) {
    mostrar("" + d + " e divisivel por 2");
  }
  if (d % 3 === 0) {
    mostrar("" + d + " e divisivel por 3");
  }
}
