/**
 * Numero_Nao_Maior_Que_3
 * Convertido do VisualG: Página 41  Exercício 4 ( K ).alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 12
 */
function exercicioK() {
  let valor = 0; // inteiro

  valor = parseInt(prompt("Digite um valor inteiro: "));
  if (valor <= 3) {   // <-- breakpoint sugerido
    mostrar("O valor informado e: " + valor);
  }
}
