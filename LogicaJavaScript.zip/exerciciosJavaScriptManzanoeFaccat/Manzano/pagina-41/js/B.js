/**
 * Modulo_Numero
 * Convertido do VisualG: Página 41  Exercício 4 (B).alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 12
 */
function exercicioB() {
  let numero = 0; // inteiro

  numero = parseInt(prompt("Digite um numero inteiro: "));
  if (numero < 0) {   // <-- breakpoint sugerido
    numero = numero * -1;
  }
  mostrar("O modulo do numero e: " + numero);
}
