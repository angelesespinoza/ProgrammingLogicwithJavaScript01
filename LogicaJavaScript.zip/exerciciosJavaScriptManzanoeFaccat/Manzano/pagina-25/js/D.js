/**
 * Combustivel_Viagem
 * Convertido do VisualG: Página 25  Exercício 7 (D).alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 13
 */
function exercicioD() {
  let tempo = 0, velocidade = 0, distancia = 0, litrosUsados = 0; // real

  tempo = parseFloat(prompt("Digite o tempo gasto na viagem: ").replace(",", "."));
  velocidade = parseFloat(prompt("Digite a velocidade media: ").replace(",", "."));
  distancia = tempo * velocidade;   // <-- breakpoint sugerido
  litrosUsados = distancia / 12;
  mostrar("Velocidade media: " + velocidade);
  mostrar("Tempo gasto: " + tempo);
  mostrar("Distancia percorrida: " + distancia);
  mostrar("Litros de combustivel utilizados: " + litrosUsados);
}
