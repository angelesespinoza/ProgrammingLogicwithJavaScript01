/**
 * Troca_AB
 * Convertido do VisualG: Página 25  Exercício 7 (F).alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 13
 */
function exercicioF() {
  let a = 0, b = 0, aux = 0; // real

  a = parseFloat(prompt("Digite o valor de A: ").replace(",", "."));
  b = parseFloat(prompt("Digite o valor de B: ").replace(",", "."));
  aux = a;   // <-- breakpoint sugerido
  a = b;
  b = aux;
  mostrar("Apos a troca:");
  mostrar("A = " + a);
  mostrar("B = " + b);
}
