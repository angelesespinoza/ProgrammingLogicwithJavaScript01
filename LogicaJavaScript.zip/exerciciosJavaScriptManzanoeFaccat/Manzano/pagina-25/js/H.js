/**
 * Volume_Caixa
 * Convertido do VisualG: Página 25  Exercício 7 (H).alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 14
 */
function exercicioH() {
  let comprimento = 0, largura = 0, altura = 0, volume = 0; // real

  comprimento = parseFloat(prompt("Digite o comprimento: ").replace(",", "."));
  largura = parseFloat(prompt("Digite a largura: ").replace(",", "."));
  altura = parseFloat(prompt("Digite a altura: ").replace(",", "."));
  volume = comprimento * largura * altura;   // <-- breakpoint sugerido
  mostrar("O volume da caixa e: " + volume);
}
