/**
 * Volume_Lata_Oleo
 * Convertido do VisualG: Página 25  Exercício 7 (C).alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 13
 */
function exercicioC() {
  let raio = 0, altura = 0, volume = 0; // real

  raio = parseFloat(prompt("Digite o raio da lata: ").replace(",", "."));
  altura = parseFloat(prompt("Digite a altura da lata: ").replace(",", "."));
  volume = Math.PI * raio**2 * altura;   // <-- breakpoint sugerido
  mostrar("O volume da lata de oleo e: " + volume);
}
