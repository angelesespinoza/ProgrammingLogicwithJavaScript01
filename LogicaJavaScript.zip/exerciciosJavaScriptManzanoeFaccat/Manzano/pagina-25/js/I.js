/**
 * QuadradoDaDiferenca
 * Convertido do VisualG: Página 25  Exercício 7 ( I ).alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 14
 */
function exercicioI() {
  let a = 0, b = 0; // inteiro
  let resultado = 0; // real

  a = parseInt(prompt("Digite o valor de a: "));
  b = parseInt(prompt("Digite o valor de b: "));
  resultado = (a - b) ** 2;   // <-- breakpoint sugerido
  mostrar(resultado);
}
