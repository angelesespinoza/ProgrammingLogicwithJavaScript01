/**
 * Real_para_Dolar
 * Convertido do VisualG: Página 25  Exercício 7 ( K ).alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 13
 */
function exercicioK() {
  let cotacao = 0, reais = 0, dolares = 0; // real

  cotacao = parseFloat(prompt("Digite a cotacao do dolar: ").replace(",", "."));
  reais = parseFloat(prompt("Digite a quantidade de reais: ").replace(",", "."));
  dolares = reais / cotacao;   // <-- breakpoint sugerido
  mostrar("Valor em dolares: " + dolares);
}
