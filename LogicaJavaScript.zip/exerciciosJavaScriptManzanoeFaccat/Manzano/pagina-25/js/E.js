/**
 * Prestacao_Atraso
 * Convertido do VisualG: Página 25  Exercício 7 (E).alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 14
 */
function exercicioE() {
  let valor = 0, taxa = 0, tempo = 0, prestacao = 0; // real

  valor = parseFloat(prompt("Digite o valor da prestacao: ").replace(",", "."));
  taxa = parseFloat(prompt("Digite a taxa de juros (%): ").replace(",", "."));
  tempo = parseFloat(prompt("Digite o tempo de atraso: ").replace(",", "."));
  prestacao = valor + (valor * taxa / 100) * tempo;   // <-- breakpoint sugerido
  mostrar("O valor da prestacao em atraso e: " + prestacao);
}
