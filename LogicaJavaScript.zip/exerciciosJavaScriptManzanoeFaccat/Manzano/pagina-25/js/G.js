/**
 * SomaE_Multiplicacao_Quatro_Numeros
 * Convertido do VisualG: Página 25  Exercício 7 (G).alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 15
 */
function exercicioG() {
  let a = 0, b = 0, c = 0, d = 0, sab = 0, sac = 0, sad = 0, sbc = 0, sbd = 0, scd = 0, mab = 0, mac = 0, mad = 0, mbc = 0, mbd = 0, mcd = 0; // inteiro

  a = parseInt(prompt("Digite o valor de A: "));
  b = parseInt(prompt("Digite o valor de B: "));
  c = parseInt(prompt("Digite o valor de C: "));
  d = parseInt(prompt("Digite o valor de D: "));
  sab = a + b;   // <-- breakpoint sugerido
  sac = a + c;
  sad = a + d;
  sbc = b + c;
  sbd = b + d;
  scd = c + d;
  mab = a * b;
  mac = a * c;
  mad = a * d;
  mbc = b * c;
  mbd = b * d;
  mcd = c * d;
  mostrar("Somas:");
  mostrar("A+B=" + sab + "  A+C=" + sac + "  A+D=" + sad);
  mostrar("B+C=" + sbc + "  B+D=" + sbd + "  C+D=" + scd);
  mostrar("Multiplicacoes:");
  mostrar("A*B=" + mab + "  A*C=" + mac + "  A*D=" + mad);
  mostrar("B*C=" + mbc + "  B*D=" + mbd + "  C*D=" + mcd);
}
