/**
 * Soma_dos_Quadrados
 * Convertido do VisualG: Página 25  Exercício 7 ( m ).alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 14
 */
function exercicioM() {
  let a = 0, b = 0, c = 0, soma = 0; // real

  a = parseFloat(prompt("Digite o valor de A: ").replace(",", "."));
  b = parseFloat(prompt("Digite o valor de B: ").replace(",", "."));
  c = parseFloat(prompt("Digite o valor de C: ").replace(",", "."));
  soma = a**2 + b**2 + c**2;   // <-- breakpoint sugerido
  mostrar("A soma dos quadrados e: " + soma);
}
