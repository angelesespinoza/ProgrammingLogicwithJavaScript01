/**
 * Conversao_Fahrenheit_Celsius
 * Convertido do VisualG: Página 25  Exercício 7 (B).alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 12
 */
function exercicioB() {
  let f = 0, c = 0; // real

  f = parseFloat(prompt("Digite a temperatura em graus Fahrenheit: ").replace(",", "."));
  c = (f - 32) * (5 / 9);   // <-- breakpoint sugerido
  mostrar("A temperatura em Celsius e: " + c);
}
