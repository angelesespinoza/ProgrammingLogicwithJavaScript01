/**
 * Conversao_Celsius_Fahrenheit
 * Convertido do VisualG: Página 25  Exercício 7 (A).alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 12
 */
function exercicioA() {
  let c = 0, f = 0; // real

  c = parseFloat(prompt("Digite a temperatura em graus Celsius: ").replace(",", "."));
  f = (9 * c + 160) / 5;   // <-- breakpoint sugerido
  mostrar("A temperatura em Fahrenheit e: " + f);
}
