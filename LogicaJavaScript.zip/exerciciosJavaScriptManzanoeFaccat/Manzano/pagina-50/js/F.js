/**
 * Soma_Media_Ate_Negativo
 * Convertido do VisualG: Página 46  Exercício 5.1.1 (F).alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 12
 */
function exercicioF() {
  let valor = 0, qtd = 0; // inteiro
  let soma = 0, media = 0; // real

  soma = 0;   // <-- breakpoint sugerido
  qtd = 0;
  valor = parseInt(prompt("Digite um valor (negativo para parar): "));
  do {
    if (valor >= 0) {
      soma = soma + valor;
      qtd = qtd + 1;
      valor = parseInt(prompt("Digite outro valor (negativo para parar): "));
    }
  } while (!(valor < 0));
  mostrar("Soma dos valores: " + soma);
  mostrar("Quantidade de valores lidos: " + qtd);
  if (qtd > 0) {
    media = soma / qtd;
    mostrar("Media aritmetica: " + media);
  } else {
    mostrar("Nenhum valor positivo foi informado, nao e possivel calcular a media");
  }
}
