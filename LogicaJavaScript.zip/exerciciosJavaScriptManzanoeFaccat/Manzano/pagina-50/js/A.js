/**
 * Quadrados_15_200_Repita
 * Convertido do VisualG: Página 50  Exercício 5.2.1 (A).alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 11
 */
function exercicioA() {
  let numero = 0; // inteiro

  numero = 15;   // <-- breakpoint sugerido
  do {
    mostrar("" + numero + "^2 = " + (numero**2));
    numero = numero + 1;
  } while (!(numero > 200));
}
