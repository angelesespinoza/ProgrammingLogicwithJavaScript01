/**
 * Maior_Menor_Ate_Negativo_Repita
 * Convertido do VisualG: Página 46  Exercício 5.1.1 ( I ).alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 12
 */
function exercicioI() {
  let valor = 0, maior = 0, menor = 0; // inteiro

  valor = parseInt(prompt("Digite um valor positivo (negativo para parar): "));
  maior = valor;   // <-- breakpoint sugerido
  menor = valor;
  do {
    if (valor > maior) {
      maior = valor;
    }
    if (valor < menor) {
      menor = valor;
    }
    valor = parseInt(prompt("Digite outro valor (negativo para parar): "));
  } while (!(valor < 0));
  mostrar("Maior valor informado: " + maior);
  mostrar("Menor valor informado: " + menor);
}
