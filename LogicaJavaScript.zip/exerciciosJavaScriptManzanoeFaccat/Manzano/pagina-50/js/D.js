/**
 * Graos_de_Trigo
 * Convertido do VisualG: Página 50  Exercício 5.2.1 (D).alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 12
 */
function exercicioD() {
  let casa = 0; // inteiro
  let graos = 0, total = 0; // real

  casa = 1;   // <-- breakpoint sugerido
  graos = 1;
  total = 0;
  do {
    total = total + graos;
    graos = graos * 2;
    casa = casa + 1;
  } while (!(casa > 64));
  mostrar("Total de graos no tabuleiro: " + total);
}
