/**
 * Soma_dos_Fatoriais
 * Convertido do VisualG: Página 46  Exercício 5.1.1 (E).alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 11
 */
function exercicioE() {
  let cont = 0, n = 0, i = 0, fatorial = 0, soma = 0; // inteiro

  soma = 0;   // <-- breakpoint sugerido
  cont = 1;
  do {
    n = parseInt(prompt("Digite o valor " + cont + ": "));
    fatorial = 1;
    i = 1;
    do {
      fatorial = fatorial * i;
      i = i + 1;
    } while (!(i > n));
    soma = soma + fatorial;
    cont = cont + 1;
  } while (!(cont > 15));
  mostrar("A soma dos fatoriais e: " + soma);
}
