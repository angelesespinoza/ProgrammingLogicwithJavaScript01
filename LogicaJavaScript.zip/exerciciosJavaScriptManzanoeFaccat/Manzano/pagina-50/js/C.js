/**
 * Divisiveis_por_4_Repita
 * Convertido do VisualG: Página 50  Exercício 5.2.1 (C).alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 11
 */
function exercicioC() {
  let numero = 0; // inteiro

  numero = 1;   // <-- breakpoint sugerido
  do {
    if (numero % 4 === 0) {
      mostrar(numero);
    }
    numero = numero + 1;
  } while (!(numero >= 200));
}
