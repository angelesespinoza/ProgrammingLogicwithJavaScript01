/**
 * Soma_Pares_1_500_Repita
 * Convertido do VisualG: Página 50  Exercício 5.2.1 (B).alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 11
 */
function exercicioB() {
  let numero = 0, soma = 0; // inteiro

  numero = 1;   // <-- breakpoint sugerido
  soma = 0;
  do {
    if (numero % 2 === 0) {
      soma = soma + numero;
    }
    numero = numero + 1;
  } while (!(numero > 500));
  mostrar("A soma dos numeros pares de 1 a 500 e: " + soma);
}
