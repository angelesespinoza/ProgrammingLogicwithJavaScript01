/**
 * Fatorial_dos_Impares
 * Convertido do VisualG: Página 46  Exercício 5.1.1 (G).alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 11
 */
function exercicioG() {
  let numero = 0, i = 0, fatorial = 0; // inteiro

  numero = 1;   // <-- breakpoint sugerido
  do {
    if (numero % 2 !== 0) {
      fatorial = 1;
      i = 1;
      do {
        fatorial = fatorial * i;
        i = i + 1;
      } while (!(i > numero));
      mostrar("Fatorial de " + numero + " = " + fatorial);
    }
    numero = numero + 1;
  } while (!(numero > 10));
}
