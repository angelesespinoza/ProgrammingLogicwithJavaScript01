/**
 * Area_Total_Residencia_Repita
 * Convertido do VisualG: Página 46  Exercício 5.1.1 (H).alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 12
 */
function exercicioH() {
  let largura = 0, comprimento = 0, area = 0, areaTotal = 0; // real
  let nomeComodo = "", resp = ""; // literal

  areaTotal = 0;   // <-- breakpoint sugerido
  do {
    nomeComodo = prompt("Digite o nome do comodo: ");
    largura = parseFloat(prompt("Digite a largura: ").replace(",", "."));
    comprimento = parseFloat(prompt("Digite o comprimento: ").replace(",", "."));
    area = largura * comprimento;
    areaTotal = areaTotal + area;
    mostrar("Area do comodo " + nomeComodo + ": " + area);
    resp = prompt("Deseja continuar? (Digite NAO para encerrar): ");
  } while (!(resp === "NAO"));
  mostrar("Area total da residencia: " + areaTotal);
}
