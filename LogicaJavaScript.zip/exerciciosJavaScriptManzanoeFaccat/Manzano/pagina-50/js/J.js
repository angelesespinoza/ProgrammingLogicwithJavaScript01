/**
 * Divisao_Sem_DIV
 * Convertido do VisualG: Página 46  Exercício 5.1.1 ( J ).alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 13
 */
function exercicioJ() {
  let dividendo = 0, divisor = 0, resto = 0, quociente = 0; // inteiro

  dividendo = parseInt(prompt("Digite o dividendo: "));
  divisor = parseInt(prompt("Digite o divisor: "));
  resto = dividendo;   // <-- breakpoint sugerido
  quociente = 0;
  do {
    if (resto >= divisor) {
      resto = resto - divisor;
      quociente = quociente + 1;
    }
  } while (!(resto < divisor));
  mostrar("O resultado da divisao (quociente) e: " + quociente);
}
