/**
 * Fibonacci_Para
 * Convertido do VisualG: Página 66  Exercício 5.6.1 ( I ).alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 11
 */
function exercicioI() {
  let t1 = 0, t2 = 0, prox = 0, cont = 0; // inteiro

  t1 = 1;   // <-- breakpoint sugerido
  t2 = 1;
  mostrar(t1);
  mostrar(t2);
  for (cont = 3; cont <= 15; cont++) {
    prox = t1 + t2;
    mostrar(prox);
    t1 = t2;
    t2 = prox;
  }
}
