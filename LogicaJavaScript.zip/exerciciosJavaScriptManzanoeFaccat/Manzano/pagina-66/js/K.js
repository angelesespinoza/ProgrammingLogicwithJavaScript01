/**
 * Fatorial_dos_Impares_Para
 * Convertido do VisualG: Página 66  Exercício 5.6.1 ( K).alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 11
 */
function exercicioK() {
  let numero = 0, i = 0, fatorial = 0; // inteiro

  for (numero = 1; numero <= 10; numero++) {   // <-- breakpoint sugerido
    if (numero % 2 !== 0) {
      fatorial = 1;
      for (i = 1; i <= numero; i++) {
        fatorial = fatorial * i;
      }
      mostrar("Fatorial de " + numero + " = " + fatorial);
    }
  }
}
