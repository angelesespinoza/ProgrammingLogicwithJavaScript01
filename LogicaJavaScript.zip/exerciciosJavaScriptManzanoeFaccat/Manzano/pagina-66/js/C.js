/**
 * Soma_100_Primeiros_Para
 * Convertido do VisualG: Página 66  Exercício 5.6.1 (C).alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 11
 */
function exercicioC() {
  let cont = 0, soma = 0; // inteiro

  soma = 0;   // <-- breakpoint sugerido
  for (cont = 1; cont <= 100; cont++) {
    soma = soma + cont;
  }
  mostrar("A soma dos 100 primeiros numeros e: " + soma);
}
