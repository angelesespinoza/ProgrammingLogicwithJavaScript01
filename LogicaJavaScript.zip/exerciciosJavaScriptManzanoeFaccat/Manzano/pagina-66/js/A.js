/**
 * Quadrados_15_200_Para
 * Convertido do VisualG: Página 66  Exercício 5.6.1 (A).alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 11
 */
function exercicioA() {
  let numero = 0; // inteiro

  for (numero = 15; numero <= 200; numero++) {   // <-- breakpoint sugerido
    mostrar("" + numero + "^2 = " + (numero**2));
  }
}
