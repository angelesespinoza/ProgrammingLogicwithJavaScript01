/**
 * Conversao_10_em_10_Para
 * Convertido do VisualG: Página 66  Exercício 5.6.1 ( J).alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 12
 */
function exercicioJ() {
  let c = 0; // inteiro
  let f = 0; // real

  for (c = 10; c <= 100; c += 10) {   // <-- breakpoint sugerido
    f = (9 * c + 160) / 5;
    mostrar("" + c + " graus Celsius = " + f + " graus Fahrenheit");
  }
}
