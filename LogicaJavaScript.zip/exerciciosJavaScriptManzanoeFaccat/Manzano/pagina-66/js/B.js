/**
 * Tabuada_Para
 * Convertido do VisualG: Página 66  Exercício 5.6.1 (B).alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 12
 */
function exercicioB() {
  let numero = 0, cont = 0; // inteiro

  numero = parseInt(prompt("Digite um numero para ver a tabuada: "));
  for (cont = 1; cont <= 10; cont++) {   // <-- breakpoint sugerido
    mostrar("" + numero + " x " + cont + " = " + (numero * cont));
  }
}
