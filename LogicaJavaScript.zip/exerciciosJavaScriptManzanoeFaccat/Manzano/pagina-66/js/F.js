/**
 * Divisiveis_por_4_Para
 * Convertido do VisualG: Página 66  Exercício 5.6.1 (F).alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 11
 */
function exercicioF() {
  let numero = 0; // inteiro

  for (numero = 1; numero <= 199; numero++) {   // <-- breakpoint sugerido
    if (numero % 4 === 0) {
      mostrar(numero);
    }
  }
}
