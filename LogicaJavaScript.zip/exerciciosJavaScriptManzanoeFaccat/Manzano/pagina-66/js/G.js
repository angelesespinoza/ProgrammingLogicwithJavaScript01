/**
 * Potencias_de_3_Para
 * Convertido do VisualG: Página 66  Exercício 5.6.1 (G).alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 11
 */
function exercicioG() {
  let expoente = 0, potencia = 0; // inteiro

  potencia = 1;   // <-- breakpoint sugerido
  for (expoente = 0; expoente <= 15; expoente++) {
    mostrar("3^" + expoente + " = " + potencia);
    potencia = potencia * 3;
  }
}
