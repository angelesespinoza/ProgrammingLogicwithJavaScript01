/**
 * Potencia_Base_Expoente_Para
 * Convertido do VisualG: Página 66  Exercício 5.6.1 (H).alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 13
 */
function exercicioH() {
  let base = 0, expoente = 0, cont = 0, potencia = 0; // inteiro

  base = parseInt(prompt("Digite a base: "));
  expoente = parseInt(prompt("Digite o expoente: "));
  potencia = 1;   // <-- breakpoint sugerido
  for (cont = 1; cont <= expoente; cont++) {
    potencia = potencia * base;
  }
  mostrar("" + base + " elevado a " + expoente + " e igual a " + potencia);
}
