/**
 * Soma_Pares_1_500_Para
 * Convertido do VisualG: Página 66  Exercício 5.6.1 (D).alg
 * Para rodar: abra o index.html no navegador, clique no botao do exercicio e veja o resultado na pagina (tambem no Console, F12).
 * Para depurar: coloque um breakpoint aqui, abra o index.html no VS Code e tecle F5; ao clicar no botao a execucao para.
 * Breakpoint sugerido: linha 11
 */
function exercicioD() {
  let numero = 0, soma = 0; // inteiro

  soma = 0;   // <-- breakpoint sugerido
  for (numero = 1; numero <= 500; numero++) {
    if (numero % 2 === 0) {
      soma = soma + numero;
    }
  }
  mostrar("A soma dos numeros pares de 1 a 500 e: " + soma);
}
