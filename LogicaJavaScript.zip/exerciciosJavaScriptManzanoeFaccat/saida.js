// Mostra o resultado dos exercicios na pagina (caixa "Resultado") e tambem no Console (F12).

function limparSaida() {
  const caixa = document.getElementById("saida");
  if (caixa) caixa.textContent = "";
}

function mostrar(texto) {
  console.log(texto);
  const caixa = document.getElementById("saida");
  if (caixa) {
    const linha = document.createElement("div");
    linha.textContent = String(texto);
    caixa.appendChild(linha);
  }
}
